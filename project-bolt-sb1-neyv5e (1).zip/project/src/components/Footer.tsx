import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const Footer = () => {
  const { t } = useTranslation();

  return (
    <footer className="bg-blue-900 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">NinoShop 🛍️</h3>
            <p className="text-blue-200">{t('footer.slogan')}</p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">{t('contact.title')}</h3>
            <div className="space-y-2">
              <p className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span>+228 71006757 (WhatsApp)</span>
              </p>
              <p className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>ninolars6@gmail.com</span>
              </p>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-4 border-t border-blue-800 text-center text-blue-200">
          <p>&copy; {new Date().getFullYear()} NinoShop. {t('footer.rights')}</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;