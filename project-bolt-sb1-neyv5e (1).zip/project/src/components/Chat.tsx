import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Video, Phone, Send, Image as ImageIcon } from 'lucide-react';
import { useStore } from '../store/useStore';

const Chat = () => {
  const [newMessage, setNewMessage] = useState('');
  const [selectedContact, setSelectedContact] = useState<string | null>(null);
  const navigate = useNavigate();
  const { messages, addMessage } = useStore();

  const contacts = ['Alice', 'Bob', 'Charlie'];

  const startVideoCall = () => {
    if (selectedContact) {
      const roomId = Math.random().toString(36).substring(7);
      navigate(`/call/${roomId}`);
    }
  };

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !selectedContact) return;

    const message = {
      id: Date.now().toString(),
      sender: 'me',
      content: newMessage,
      timestamp: Date.now(),
      type: 'text' as const,
    };

    addMessage(selectedContact, message);
    setNewMessage('');
  };

  const currentMessages = selectedContact ? messages[selectedContact] || [] : [];

  return (
    <div className="bg-white rounded-lg shadow-lg h-[calc(100vh-12rem)] flex">
      <div className="w-1/4 border-r border-gray-200 p-4">
        <h2 className="text-lg font-semibold mb-4">Contacts</h2>
        <div className="space-y-2">
          {contacts.map(contact => (
            <button
              key={contact}
              onClick={() => setSelectedContact(contact)}
              className={`w-full p-3 rounded-lg text-left ${
                selectedContact === contact ? 'bg-blue-50' : 'hover:bg-gray-50'
              }`}
            >
              {contact}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col">
        {selectedContact ? (
          <>
            <div className="p-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="font-semibold">{selectedContact}</h3>
              <div className="flex space-x-2">
                <button
                  onClick={() => {}}
                  className="p-2 rounded-full hover:bg-gray-100"
                >
                  <Phone className="w-5 h-5 text-blue-600" />
                </button>
                <button
                  onClick={startVideoCall}
                  className="p-2 rounded-full hover:bg-gray-100"
                >
                  <Video className="w-5 h-5 text-blue-600" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {currentMessages.map(message => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.sender === 'me' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-xs px-4 py-2 rounded-lg ${
                      message.sender === 'me'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100'
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={sendMessage} className="p-4 border-t border-gray-200">
              <div className="flex space-x-2">
                <button
                  type="button"
                  className="p-2 rounded-full hover:bg-gray-100"
                >
                  <ImageIcon className="w-5 h-5 text-gray-600" />
                </button>
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  className="flex-1 border border-gray-300 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Message..."
                />
                <button
                  type="submit"
                  className="p-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </form>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center text-gray-500">
            Sélectionnez un contact pour commencer à discuter
          </div>
        )}
      </div>
    </div>
  );
};

export default Chat;