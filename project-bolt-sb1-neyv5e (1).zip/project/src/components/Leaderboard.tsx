import React from 'react';
import { Trophy } from 'lucide-react';

interface Player {
  name: string;
  score: number;
  manga: string;
  date: string;
}

interface LeaderboardProps {
  players: Player[];
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ players }) => {
  const sortedPlayers = [...players].sort((a, b) => b.score - a.score);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto">
      <div className="flex items-center justify-center gap-2 mb-6">
        <Trophy className="w-8 h-8 text-yellow-500" />
        <h2 className="text-2xl font-bold text-blue-900">Classement des Otakus</h2>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-blue-50">
              <th className="px-4 py-2 text-left text-blue-900">Rang</th>
              <th className="px-4 py-2 text-left text-blue-900">Joueur</th>
              <th className="px-4 py-2 text-left text-blue-900">Score</th>
              <th className="px-4 py-2 text-left text-blue-900">Manga</th>
              <th className="px-4 py-2 text-left text-blue-900">Date</th>
            </tr>
          </thead>
          <tbody>
            {sortedPlayers.map((player, index) => (
              <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-blue-50'}>
                <td className="px-4 py-2">#{index + 1}</td>
                <td className="px-4 py-2 font-medium">{player.name}</td>
                <td className="px-4 py-2">{player.score}/30</td>
                <td className="px-4 py-2">{player.manga}</td>
                <td className="px-4 py-2">{player.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};