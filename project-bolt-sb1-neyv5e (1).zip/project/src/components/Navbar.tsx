import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Phone, Mail } from 'lucide-react';
import LanguageSelector from './LanguageSelector';
import { useTranslation } from 'react-i18next';

const Navbar = () => {
  const { t } = useTranslation();
  
  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <ShoppingBag className="w-8 h-8 text-blue-600" />
            <span className="text-xl font-bold text-blue-900">NinoShop</span>
          </Link>

          <div className="flex items-center space-x-6">
            <Link to="/contact" className="text-gray-600 hover:text-blue-600">
              {t('nav.contact')}
            </Link>
            <LanguageSelector />
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <Phone className="w-4 h-4" />
              <span>+228 71006757</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;