import React from 'react';
import { useEffect, useState } from 'react';

interface ConfettiProps {
  active: boolean;
}

export const Confetti: React.FC<ConfettiProps> = ({ active }) => {
  const [particles, setParticles] = useState<JSX.Element[]>([]);

  useEffect(() => {
    if (active) {
      const newParticles = Array.from({ length: 50 }).map((_, i) => {
        const left = Math.random() * 100;
        const animationDuration = 1 + Math.random() * 2;
        const size = 5 + Math.random() * 10;

        return (
          <div
            key={i}
            className="absolute"
            style={{
              left: `${left}vw`,
              top: '-20px',
              width: `${size}px`,
              height: `${size}px`,
              background: `hsl(${Math.random() * 360}, 70%, 50%)`,
              borderRadius: '50%',
              animation: `fall ${animationDuration}s linear forwards`
            }}
          />
        );
      });

      setParticles(newParticles);

      const timer = setTimeout(() => {
        setParticles([]);
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [active]);

  return (
    <div className="fixed inset-0 pointer-events-none">
      {particles}
    </div>
  );
};