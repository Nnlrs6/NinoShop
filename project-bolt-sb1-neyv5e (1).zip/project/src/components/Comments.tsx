import React, { useState } from 'react';
import { MessageSquare } from 'lucide-react';

interface Comment {
  id: number;
  username: string;
  content: string;
  timestamp: string;
}

export const Comments: React.FC<{ username: string }> = ({ username }) => {
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;

    const comment: Comment = {
      id: Date.now(),
      username,
      content: newComment,
      timestamp: new Date().toLocaleString()
    };

    setComments([comment, ...comments]);
    setNewComment('');
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto mt-8">
      <div className="flex items-center gap-2 mb-6">
        <MessageSquare className="w-6 h-6 text-blue-600" />
        <h3 className="text-xl font-bold text-blue-900">Commentaires</h3>
      </div>

      <form onSubmit={handleSubmit} className="mb-6">
        <textarea
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
          placeholder="Partage ton expérience avec la communauté ! 💭"
          className="w-full p-3 border border-blue-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          rows={3}
        />
        <button
          type="submit"
          className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Publier 📝
        </button>
      </form>

      <div className="space-y-4">
        {comments.map((comment) => (
          <div key={comment.id} className="border-b border-blue-100 pb-4">
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium text-blue-900">{comment.username}</span>
              <span className="text-sm text-gray-500">{comment.timestamp}</span>
            </div>
            <p className="text-gray-700">{comment.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
};