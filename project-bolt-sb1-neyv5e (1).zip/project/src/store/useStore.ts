import create from 'zustand';

interface User {
  phoneNumber: string;
  isAuthenticated: boolean;
}

interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: number;
  type: 'text' | 'image' | 'file';
}

interface Store {
  user: User | null;
  messages: Record<string, Message[]>;
  setUser: (user: User | null) => void;
  addMessage: (contactId: string, message: Message) => void;
}

export const useStore = create<Store>((set) => ({
  user: null,
  messages: {},
  setUser: (user) => set({ user }),
  addMessage: (contactId, message) =>
    set((state) => ({
      messages: {
        ...state.messages,
        [contactId]: [...(state.messages[contactId] || []), message],
      },
    })),
}));