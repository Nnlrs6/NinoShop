import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { products, categories } from '../data/products';
import { Mail } from 'lucide-react';
import toast from 'react-hot-toast';

const Category = () => {
  const { id } = useParams();
  const [email, setEmail] = useState('');
  const [showEmailInput, setShowEmailInput] = useState<string | null>(null);

  const category = categories.find(c => c.id === id);
  const categoryProducts = products.filter(p => p.category === id);

  const handleOrder = async (productName: string) => {
    if (!email && !showEmailInput) {
      setShowEmailInput(productName);
      return;
    }

    if (email) {
      const message = `Hello, I'm interested in this product: ${productName}!`;
      const mailtoLink = `mailto:ninolars6@gmail.com?subject=Product Inquiry: ${productName}&body=${encodeURIComponent(message)}`;
      window.location.href = mailtoLink;
      
      const whatsappMessage = `https://wa.me/22871006757?text=${encodeURIComponent(message)}`;
      window.open(whatsappMessage, '_blank');
      
      toast.success('Order request sent! We\'ll contact you soon 🎉');
      setShowEmailInput(null);
      setEmail('');
    }
  };

  if (!category) return <div>Category not found</div>;

  return (
    <div>
      <h1 className="text-3xl font-bold text-blue-900 mb-6">{category.name}</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categoryProducts.map((product) => (
          <div key={product.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h2 className="text-xl font-bold text-blue-900 mb-2">{product.name}</h2>
              <p className="text-gray-600 mb-4">{product.description}</p>
              
              <ul className="space-y-2 mb-4">
                {product.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-gray-600">
                    <span className="mr-2">✨</span>
                    {feature}
                  </li>
                ))}
              </ul>

              {showEmailInput === product.name ? (
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Mail className="w-5 h-5 text-blue-600" />
                    <input
                      type="email"
                      placeholder="Enter your email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="flex-1 p-2 border rounded-md"
                      required
                    />
                  </div>
                  <button
                    onClick={() => handleOrder(product.name)}
                    className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition-colors"
                  >
                    Confirm Order 🚀
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => handleOrder(product.name)}
                  className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition-colors"
                >
                  Order Now 🛍️
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Category;