import React from 'react';
import { Phone, Mail, MessageSquare } from 'lucide-react';

const Contact = () => {
  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold text-blue-900 mb-6">Contact Us 📞</h1>
      
      <div className="bg-white rounded-lg shadow-md p-6 space-y-6">
        <div className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <Phone className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-blue-900">Phone/WhatsApp</h2>
            <p className="text-gray-600">+228 71006757</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <Mail className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-blue-900">Email</h2>
            <p className="text-gray-600">ninolars6@gmail.com</p>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full">
            <MessageSquare className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h2 className="text-xl font-semibold text-blue-900">Business Hours</h2>
            <p className="text-gray-600">Monday - Saturday: 9:00 AM - 8:00 PM</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;