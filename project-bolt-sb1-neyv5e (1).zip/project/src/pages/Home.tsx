import React from 'react';
import { Link } from 'react-router-dom';
import { categories } from '../data/products';
import { Smartphone, Laptop, Headphones } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const iconMap: { [key: string]: React.ComponentType } = {
  smartphone: Smartphone,
  laptop: Laptop,
  headphones: Headphones,
};

const Home = () => {
  const { t } = useTranslation();

  return (
    <div className="space-y-8">
      <section className="text-center">
        <h1 className="text-4xl font-bold text-blue-900 mb-4">
          {t('home.welcome')}
        </h1>
        <p className="text-xl text-gray-600">
          {t('home.subtitle')}
        </p>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {categories.map((category) => {
          const Icon = iconMap[category.icon];
          return (
            <Link
              key={category.id}
              to={`/category/${category.id}`}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center justify-center mb-4">
                {Icon && <Icon className="w-12 h-12 text-blue-600" />}
              </div>
              <h2 className="text-xl font-bold text-center text-blue-900 mb-2">
                {t(`categories.${category.id}.name`)}
              </h2>
              <p className="text-gray-600 text-center">
                {t(`categories.${category.id}.description`)}
              </p>
            </Link>
          );
        })}
      </section>
    </div>
  );
};

export default Home;