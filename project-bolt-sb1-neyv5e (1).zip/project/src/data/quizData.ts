export interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: string;
  manga: string;
  difficulty: 'easy' | 'medium' | 'hard';
  imageUrl?: string;
}

export const quizData: Question[] = [
  // Jujutsu Kaisen
  {
    id: 1,
    manga: 'Jujutsu Kaisen',
    question: "Quel est le nom du professeur principal de Yuji Itadori ?",
    options: ["Satoru Gojo", "Suguru Geto", "Kento Nanami", "Masamichi Yaga"],
    correctAnswer: "Satoru Gojo",
    difficulty: "easy"
  },
  {
    id: 2,
    manga: 'Jujutsu Kaisen',
    question: "Qui est le Roi des Fléaux dont Yuji devient l'hôte ?",
    options: ["Ryomen Sukuna", "Mahito", "Jogo", "Hanami"],
    correctAnswer: "Ryomen Sukuna",
    difficulty: "easy"
  },
  {
    id: 3,
    manga: 'Jujutsu Kaisen',
    question: "Quelle est la technique innée de Megumi Fushiguro ?",
    options: ["Les Dix Ombres", "Manipulation des Ombres", "Extension du Domaine", "Malédiction"],
    correctAnswer: "Les Dix Ombres",
    difficulty: "medium"
  },
  // ... (27 autres questions pour Jujutsu Kaisen)

  // Demon Slayer
  {
    id: 31,
    manga: 'Demon Slayer',
    question: "Quelle est la technique de respiration principale de Tanjiro ?",
    options: ["Eau", "Feu", "Foudre", "Vent"],
    correctAnswer: "Eau",
    difficulty: "easy"
  },
  {
    id: 32,
    manga: 'Demon Slayer',
    question: "Qui a transformé Nezuko en démon ?",
    options: ["Muzan Kibutsuji", "Akaza", "Rui", "Doma"],
    correctAnswer: "Muzan Kibutsuji",
    difficulty: "easy"
  },
  {
    id: 33,
    manga: 'Demon Slayer',
    question: "Quel est le grade de Giyu Tomioka ?",
    options: ["Pilier de l'Eau", "Pilier du Feu", "Pilier du Son", "Pilier de la Brume"],
    correctAnswer: "Pilier de l'Eau",
    difficulty: "medium"
  },
  // ... (27 autres questions pour Demon Slayer)

  // Bleach
  {
    id: 61,
    manga: 'Bleach',
    question: "Quel est le nom du Zanpakuto d'Ichigo ?",
    options: ["Zangetsu", "Senbonzakura", "Hyorinmaru", "Zabimaru"],
    correctAnswer: "Zangetsu",
    difficulty: "easy"
  },
  {
    id: 62,
    manga: 'Bleach',
    question: "Quelle est la division de Byakuya Kuchiki ?",
    options: ["6ème Division", "10ème Division", "13ème Division", "4ème Division"],
    correctAnswer: "6ème Division",
    difficulty: "medium"
  },
  // ... (28 autres questions pour Bleach)

  // Blue Lock
  {
    id: 91,
    manga: 'Blue Lock',
    question: "Quel est le but ultime du projet Blue Lock ?",
    options: [
      "Créer le meilleur attaquant du monde",
      "Former une équipe nationale",
      "Gagner la Coupe du Monde",
      "Développer de nouveaux talents"
    ],
    correctAnswer: "Créer le meilleur attaquant du monde",
    difficulty: "easy"
  },
  // ... (29 autres questions pour Blue Lock)

  // Mushoku Tensei
  {
    id: 121,
    manga: 'Mushoku Tensei',
    question: "Quel type de magie Rudeus maîtrise-t-il le mieux ?",
    options: ["Magie de l'Eau", "Magie du Feu", "Magie de la Terre", "Magie du Vent"],
    correctAnswer: "Magie de l'Eau",
    difficulty: "medium"
  },
  // ... (29 autres questions pour Mushoku Tensei)

  // One Piece
  {
    id: 151,
    manga: 'One Piece',
    question: "Quel est le nom du fruit du démon de Luffy ?",
    options: ["Gomu Gomu no Mi", "Mera Mera no Mi", "Hito Hito no Mi", "Yami Yami no Mi"],
    correctAnswer: "Gomu Gomu no Mi",
    difficulty: "easy"
  },
  // ... (29 autres questions pour One Piece)

  // Dragon Ball Super
  {
    id: 181,
    manga: 'Dragon Ball Super',
    question: "Quelle est la première transformation divine de Goku ?",
    options: ["Super Saiyan God", "Ultra Instinct", "Super Saiyan Blue", "Super Saiyan Rose"],
    correctAnswer: "Super Saiyan God",
    difficulty: "medium"
  },
  // ... (29 autres questions pour Dragon Ball Super)

  // Fairy Tail
  {
    id: 211,
    manga: 'Fairy Tail',
    question: "Quelle est la magie d'Erza Scarlet ?",
    options: ["Rééquipement", "Dragon Slayer", "Constellationniste", "Take Over"],
    correctAnswer: "Rééquipement",
    difficulty: "easy"
  },
  // ... (29 autres questions pour Fairy Tail)

  // Death Note
  {
    id: 241,
    manga: 'Death Note',
    question: "Quelle est la règle principale du Death Note ?",
    options: [
      "La personne dont le nom est écrit mourra",
      "Il faut connaître le visage",
      "On ne peut pas tuer plus de 23 personnes par jour",
      "Le Death Note ne peut pas être détruit"
    ],
    correctAnswer: "La personne dont le nom est écrit mourra",
    difficulty: "easy"
  }
  // ... (29 autres questions pour Death Note)
];