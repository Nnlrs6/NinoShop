export interface Product {
  id: string;
  name: string;
  category: string;
  description: string;
  features: string[];
  image: string;
  brand: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export const categories: Category[] = [
  {
    id: 'smartphones',
    name: 'Smartphones 📱',
    icon: 'smartphone',
    description: 'Latest smartphones from top brands'
  },
  {
    id: 'laptops',
    name: 'Laptops 💻',
    icon: 'laptop',
    description: 'Powerful laptops for work and gaming'
  },
  {
    id: 'accessories',
    name: 'Accessories 🎧',
    icon: 'headphones',
    description: 'Essential accessories for your devices'
  }
];

export const products: Product[] = [
  // Smartphones
  {
    id: 'iphone-15-pro',
    name: 'iPhone 15 Pro',
    brand: 'Apple',
    category: 'smartphones',
    description: 'The most powerful iPhone ever with A17 Pro chip',
    features: [
      'A17 Pro chip',
      'Pro camera system',
      'Titanium design',
      'Dynamic Island'
    ],
    image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569'
  },
  {
    id: 'samsung-s24-ultra',
    name: 'Samsung S24 Ultra',
    brand: 'Samsung',
    category: 'smartphones',
    description: 'Ultimate Galaxy experience with AI capabilities',
    features: [
      'Snapdragon 8 Gen 3',
      '200MP camera',
      'S Pen included',
      'AI features'
    ],
    image: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c'
  },
  {
    id: 'pixel-8-pro',
    name: 'Pixel 8 Pro',
    brand: 'Google',
    category: 'smartphones',
    description: 'The most helpful Pixel yet with Google AI',
    features: [
      'Google Tensor G3',
      'Advanced AI features',
      '50MP main camera',
      'Android 14'
    ],
    image: 'https://images.unsplash.com/photo-1635870723802-e88d76ae324e'
  },
  {
    id: 'xiaomi-14-pro',
    name: 'Xiaomi 14 Pro',
    brand: 'Xiaomi',
    category: 'smartphones',
    description: 'Premium flagship with Leica optics',
    features: [
      'Snapdragon 8 Gen 3',
      'Leica cameras',
      'MIUI 15',
      '120W charging'
    ],
    image: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97'
  },

  // Laptops
  {
    id: 'macbook-pro-16',
    name: 'MacBook Pro 16"',
    brand: 'Apple',
    category: 'laptops',
    description: 'Supercharged for pros with M3 Max chip',
    features: [
      'M3 Max chip',
      'Up to 128GB RAM',
      'Liquid Retina XDR display',
      'Up to 22 hours battery'
    ],
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8'
  },
  {
    id: 'dell-xps-15',
    name: 'Dell XPS 15',
    brand: 'Dell',
    category: 'laptops',
    description: 'Premium Windows laptop for professionals',
    features: [
      'Intel Core i9 13th Gen',
      'RTX 4070',
      'OLED display',
      'Premium build'
    ],
    image: 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45'
  },
  {
    id: 'razer-blade-18',
    name: 'Razer Blade 18',
    brand: 'Razer',
    category: 'laptops',
    description: 'Ultimate gaming laptop',
    features: [
      'Intel Core i9 HX',
      'RTX 4090',
      '240Hz display',
      'CNC aluminum'
    ],
    image: 'https://images.unsplash.com/photo-1611078489935-0cb964de46d6'
  },

  // Accessories
  {
    id: 'airpods-pro',
    name: 'AirPods Pro',
    brand: 'Apple',
    category: 'accessories',
    description: 'Premium wireless earbuds with active noise cancellation',
    features: [
      'Active Noise Cancellation',
      'Adaptive Audio',
      'Spatial Audio',
      'Water resistant'
    ],
    image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434'
  },
  {
    id: 'sony-wh1000xm5',
    name: 'WH-1000XM5',
    brand: 'Sony',
    category: 'accessories',
    description: 'Industry-leading noise cancelling headphones',
    features: [
      'Best-in-class ANC',
      '30-hour battery',
      'LDAC codec',
      'Multipoint connection'
    ],
    image: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb'
  },
  {
    id: 'samsung-watch6',
    name: 'Galaxy Watch 6 Pro',
    brand: 'Samsung',
    category: 'accessories',
    description: 'Advanced smartwatch with health features',
    features: [
      'Advanced sleep tracking',
      'ECG monitoring',
      'Wear OS',
      'Titanium build'
    ],
    image: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a'
  }
];